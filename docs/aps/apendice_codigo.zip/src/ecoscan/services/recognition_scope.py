"""Supported objects for the pilot; material labels are not object detectors."""
from dataclasses import replace

from ecoscan.classification.prediction import ClassificationPrediction


ITEMS = {
    "drink_can": ("Lata de bebida", "metal"),
    "food_can": ("Lata de conserva vazia", "metal"),
    "pet_bottle": ("Garrafa plástica PET", "plastic"),
    "plastic_container": ("Frasco ou pote plástico rígido vazio", "plastic"),
    "cardboard_box": ("Caixa de papelão", "paper_cardboard"),
    "paper_sheet": ("Folha de papel ou jornal", "paper_cardboard"),
    "glass_bottle": ("Garrafa de vidro", "glass"),
    "glass_jar": ("Pote de vidro", "glass"),
    "battery": ("Pilha ou bateria portátil", "battery"),
    "household_cell": ("Pilha cilíndrica AA ou AAA", "battery"),
    "small_electronic": ("Celular, mouse, carregador ou pequeno eletrônico", "electronic"),
    "mobile_phone": ("Celular", "electronic"),
    "computer_mouse": ("Mouse de computador", "electronic"),
    "charger": ("Carregador de celular", "electronic"),
    "out_of_scope": ("Alimento, orgânico ou outro item fora da lista", "out_of_scope"),
    "unknown": ("Não sei identificar o material", "unknown"),
}

# Preserve historic IDs for analyst review without inviting broad new labels.
RECOGNITION_ITEMS = (
    "drink_can", "food_can", "pet_bottle", "plastic_container",
    "cardboard_box", "paper_sheet", "glass_bottle", "glass_jar",
    "household_cell", "mobile_phone", "computer_mouse", "charger",
)
REPORT_ITEMS = RECOGNITION_ITEMS + ("out_of_scope", "unknown")
SCOPE_VERSION = "objects-v1"

ITEM_CONDITIONS = {
    "unspecified": "Não informado",
    "intact": "Inteiro / sem deformação",
    "crushed": "Amassado / achatado",
    "folded": "Dobrado / desmontado",
    "torn": "Rasgado / em pedaços",
    "broken": "Quebrado / cacos",
    "dirty": "Com resíduos / sujo",
}


def restrict_prediction(
    prediction: ClassificationPrediction,
    classes: tuple[str, ...],
) -> ClassificationPrediction:
    if prediction.top_class_id in classes and (
        prediction.class_id is None or prediction.class_id in classes
    ):
        return prediction
    # Keep the original scores; never promote a runner-up after rejecting a class.
    return replace(prediction, class_id=None, top_class_id="", accepted=False)
