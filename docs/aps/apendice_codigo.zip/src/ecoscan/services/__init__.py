"""Reusable application services."""

