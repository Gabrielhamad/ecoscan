"""Application orchestration layer."""

