"""Utility helpers for EcoScan."""

