from __future__ import annotations

from typing import Any
from uuid import uuid4
import time

from ecoscan.services.accounts import UserProfile
from ecoscan.services.identity import resolve_identity


def render_identity(st: Any) -> UserProfile:
    from streamlit.errors import StreamlitSecretNotFoundError

    try:
        auth = dict(st.secrets.get("auth", {}))
        access = dict(st.secrets.get("access", {}))
    except (StreamlitSecretNotFoundError, ValueError, TypeError):
        auth, access = {}, {}
    configured = all(auth.get(key) for key in (
        "client_id", "client_secret", "cookie_secret", "redirect_uri", "server_metadata_url",
    ))
    if not configured:
        from ecoscan.services.contribution_store import persistent_enabled
        try:
            if persistent_enabled():
                return _render_password_identity(st, access)
        except (ValueError, OSError):
            st.warning("Login temporariamente indisponível. Você pode continuar como visitante.")
    claims = dict(st.user) if configured else {}
    st.session_state.setdefault("visitor_identity", uuid4().hex)
    profile = resolve_identity(claims, access, st.session_state["visitor_identity"])
    previous = st.session_state.get("resolved_identity")
    if previous is not None and previous != (profile.id, profile.role):
        # Do not carry another identity's forms or analysis across a login change.
        for key in list(st.session_state):
            if key != "visitor_identity":
                del st.session_state[key]
    st.session_state["resolved_identity"] = (profile.id, profile.role)
    if claims.get("is_logged_in"):
        st.button("Sair da conta", on_click=st.logout, key="identity_logout")
        if profile.id.startswith("visitor_"):
            st.warning("Sua sessão expirou. Saia e entre novamente.")
    elif configured:
        st.button("Entrar na conta", on_click=st.login, key="identity_login")
    else:
        st.caption("Acesso público disponível. Login da secretaria ainda não configurado.")
    if st.query_params.get("profile") == "admin_secretaria" and not profile.is_admin:
        st.info("A gestão requer uma conta autorizada pela secretaria.")
    return profile


def _render_password_identity(st, access):
    from ecoscan.services.password_identity import AuthenticationUnavailableError, verified_profile

    if _render_password_recovery(st):
        st.stop()
    st.session_state.setdefault("visitor_identity", uuid4().hex)
    profile = resolve_identity({}, {}, st.session_state["visitor_identity"])
    token = st.session_state.get("auth_access_token")
    if token:
        try:
            profile = verified_profile(token, access)
        except AuthenticationUnavailableError as exc:
            # Keep the token for retry, but render no authenticated content while
            # verification is unavailable. A timeout must not erase the account.
            st.warning(str(exc))
            # Clicking already reruns this function; do not issue a second
            # immediate Auth request after a failed retry.
            st.button("Tentar validar sessão novamente", key="retry_identity")
            if st.button("Continuar como visitante", key="identity_continue_visitor"):
                st.session_state.clear()
                st.rerun()
            st.stop()
        except ValueError as exc:
            st.session_state.pop("auth_access_token", None)
            st.warning(str(exc))
    current = (profile.id, profile.role)
    if st.session_state.get("resolved_identity") not in (None, current):
        for key in list(st.session_state):
            if key not in ("visitor_identity", "auth_access_token"):
                del st.session_state[key]
    st.session_state["resolved_identity"] = current
    if profile.id.startswith("supabase_"):
        st.caption("Conectado como " + ("analista da secretaria" if profile.is_admin else "cidadão"))
        if st.button("Sair da conta", key="password_logout"):
            # Tokens are session-only. No persistent browser cookie is created.
            st.session_state.clear()
            st.rerun()
    else:
        with st.expander("Entrar ou criar conta", expanded=st.session_state.get("account_help_open", False)):
            st.caption("Visitante: análise temporária, mapa e orientações. Conta verificada: contribuições e participação vinculadas ao seu perfil.")
            login_tab, signup_tab = st.tabs(["Entrar", "Criar conta"])
            with signup_tab:
                _render_registration(st, access)
            with login_tab:
                _render_login_form(st)
            if access.get("public_signup_enabled") is True:
                _render_resend_confirmation(st)
    if st.query_params.get("profile") == "admin_secretaria" and not profile.is_admin:
        st.info("A gestão requer uma conta autorizada pela secretaria.")
    return profile


def _render_registration(st, access):
    from ecoscan.services.password_identity import register, validate_registration
    enabled = access.get("public_signup_enabled") is True
    if not enabled:
        st.info("Cadastro em preparação. O modo visitante continua disponível, sem salvar fotos, relatos ou pontos no perfil.")
        return
    st.caption("Cadastro gratuito, sem convite e sem aprovação da secretaria. Confirme seu e-mail uma única vez para participar com sua conta.")
    with st.form("account_registration", clear_on_submit=True):
        name = st.text_input("Nome", max_chars=80)
        email = st.text_input("E-mail", max_chars=254, key="signup_email")
        password = st.text_input("Senha (mínimo 12 caracteres)", type="password", max_chars=128)
        confirmation = st.text_input("Confirmar senha", type="password", max_chars=128)
        st.caption("E-mail e credenciais são tratados pelo Supabase Auth para acesso à conta. Fotos só são guardadas quando você autoriza uma contribuição.")
        consent = st.checkbox("Concordo com o uso do meu e-mail para criar e verificar minha conta.")
        submit = st.form_submit_button("Criar minha conta")
    if submit:
        if not name.strip():
            st.error("Informe seu nome para criar o perfil.")
            return
        if not consent:
            st.error("Confirme o uso do e-mail antes de continuar.")
            return
        try:
            validate_registration(email, password, confirmation)
        except ValueError as exc:
            st.error(str(exc))
            return
        now = time.monotonic()
        if now - st.session_state.get("signup_last_attempt", -60) < 60:
            st.warning("Aguarde um minuto antes de tentar novamente.")
            return
        st.session_state["signup_last_attempt"] = now
        try:
            register(email, password, confirmation, enabled=enabled, name=name)
        except ValueError as exc:
            st.error(str(exc))
        else:
            st.success("Confira sua caixa de entrada e o spam. Se este e-mail puder ser cadastrado, você receberá a confirmação. Confirme e depois entre com a senha que acabou de escolher.")
            st.info("Já possui uma conta ou recebeu um convite anteriormente? Use Entrar. Se ainda não definiu uma senha, use Esqueci minha senha. Não é necessário criar outra conta.")


def _render_login_form(st):
    from ecoscan.services.password_identity import sign_in
    with st.form("password_login", clear_on_submit=True):
        email = st.text_input("E-mail", max_chars=254)
        password = st.text_input("Senha", type="password", max_chars=256)
        submit = st.form_submit_button("Entrar")
    if submit:
        try:
            with st.spinner("Entrando na sua conta..."):
                st.session_state["auth_access_token"] = sign_in(email, password)
        except ValueError as exc:
            st.error(str(exc))
        else:
            st.rerun()
    _render_reset_request(st)


def _render_resend_confirmation(st):
    from ecoscan.services.password_identity import resend_confirmation, validate_email
    with st.expander("Não recebi a confirmação"):
        st.caption("Se o link expirou ou não chegou, solicite uma nova confirmação. Use o link mais recente recebido por e-mail.")
        with st.form("resend_confirmation", clear_on_submit=True):
            email = st.text_input("E-mail do cadastro", max_chars=254)
            sent = st.form_submit_button("Reenviar confirmação")
        if sent:
            try:
                validate_email(email)
            except ValueError as exc:
                st.error(str(exc))
                return
            now = time.monotonic()
            if now - st.session_state.get("signup_last_attempt", -60) < 60:
                st.warning("Aguarde um minuto antes de solicitar outro e-mail.")
                return
            st.session_state["signup_last_attempt"] = now
            try:
                resend_confirmation(email, enabled=True)
            except ValueError as exc:
                st.error(str(exc))
            else:
                st.success("Se houver um cadastro pendente para esse e-mail, a confirmação será reenviada. Confira também o spam.")


def _render_reset_request(st):
    from ecoscan.services.password_identity import request_password_reset, validate_email
    with st.expander("Esqueci minha senha", expanded=st.session_state.get("account_help_open", False)):
        st.caption("Esta etapa é apenas para quem já tem conta. Para começar, escolha Criar conta. Use somente o último e-mail de recuperação solicitado.")
        with st.form("password_reset_request", clear_on_submit=True):
            email = st.text_input("E-mail da conta", max_chars=254)
            sent = st.form_submit_button("Enviar link de recuperação")
        if sent:
            try:
                validate_email(email)
            except ValueError as exc:
                st.error(str(exc))
                return
            now = time.monotonic()
            if now - st.session_state.get("reset_last_attempt", -60) < 60:
                st.warning("Aguarde um minuto antes de solicitar outro e-mail.")
                return
            st.session_state["reset_last_attempt"] = now
            try:
                request_password_reset(email)
            except ValueError as exc:
                st.error(str(exc))
            else:
                st.success("Se houver uma conta para esse e-mail, você receberá um link de recuperação. Confira também o spam.")


def _render_password_recovery(st):
    from ecoscan.services.password_identity import reset_password
    # Read only our callback fields. Clear credentials from the URL immediately;
    # verify only on form submission so email preview scanners cannot consume it.
    if "token_hash" in st.query_params or st.query_params.get("type") == "recovery":
        hashes = st.query_params.get_all("token_hash")
        types = st.query_params.get_all("type")
        token_hash = hashes[0] if len(hashes) == 1 and types == ["recovery"] else ""
        st.query_params.clear()
        # A recovery link may belong to a different account than the current login.
        st.session_state.clear()
        st.session_state["password_recovery_hash"] = token_hash
    if "password_recovery_hash" not in st.session_state:
        if st.session_state.pop("password_reset_done", False):
            st.success("Senha atualizada. Entre novamente com sua nova senha.")
        return False
    st.subheader("Definir nova senha")
    st.caption("Use o link recebido por e-mail. Após salvar, entre novamente na conta.")
    with st.form("password_recovery", clear_on_submit=True):
        password = st.text_input("Nova senha (mínimo 12 caracteres)", type="password", max_chars=128)
        confirmation = st.text_input("Confirmar nova senha", type="password", max_chars=128)
        submitted = st.form_submit_button("Salvar nova senha")
    if submitted:
        try:
            reset_password(st.session_state["password_recovery_hash"], password, confirmation)
        except ValueError as exc:
            st.error(str(exc))
        else:
            st.session_state.clear()
            st.session_state["password_reset_done"] = True
            st.rerun()
    if st.button("Voltar para entrar ou solicitar outro link", key="cancel_password_recovery"):
        st.session_state.clear()
        st.session_state["account_help_open"] = True
        st.rerun()
    return True
