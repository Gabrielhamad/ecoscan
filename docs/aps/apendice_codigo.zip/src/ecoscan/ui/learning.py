from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

from ecoscan.services.learning_contributions import (
    contribution_image, contribution_package, list_contributions,
    review_contribution, submit_contribution, citizen_contributions,
)
from ecoscan.services.recognition_scope import ITEMS, ITEM_CONDITIONS, REPORT_ITEMS
from ecoscan.services.contribution_store import persistent_enabled
from ecoscan.ui.scope import render_scope as render_scope


STATUS_LABELS = {"pending": "Recebido pela secretaria", "approved": "Aprovado pelo analista",
                 "rejected": "Não aproveitado", "queued": "Na fila de treino",
                 "awaiting_validation": "Candidato treinado; aguardando validação", "excluded": "Fora do treino",
                 "waiting_dataset": "Aguardando base revisada e validação independente",
                 "training": "Treinamento em andamento", "validating": "Validando candidato",
                 "published": "Incorporada ao modelo publicado", "validation_failed": "Treinado; modelo anterior mantido após validação",
                 "failed": "Falha no processamento; nova tentativa pendente"}


def render_evaluation(st, records):
    runs = {}
    for row in records:
        outcome = row.get('training_result') or {}
        identifier = row.get('candidate_id')
        if identifier and outcome and row.get('training_status') in ('published', 'validation_failed'):
            runs.setdefault(identifier, outcome)
    if not runs:
        return
    with st.expander('Resultados dos lotes avaliados'):
        selected = st.selectbox('Lote avaliado', sorted(runs, key=lambda key: runs[key].get('evaluated_at', ''), reverse=True),
                                key='evaluated_training_batch')
        result = runs[selected]
        st.write('Candidato aprovado na avaliação' if result.get('published') else 'Modelo anterior mantido')
        columns = st.columns(2)
        for column, label, field in [(columns[0], 'Macro-F1 anterior', 'reference_macro_f1'),
                                     (columns[1], 'Macro-F1 candidato', 'candidate_macro_f1')]:
            value = result.get(field)
            column.metric(label, f'{value:.3f}' if isinstance(value, (int, float)) else 'Não registrado')
        details = result.get('by_class', {})
        if details:
            names = {'metal': 'Metal', 'plastic': 'Plástico', 'glass': 'Vidro',
                     'paper_cardboard': 'Papel e papelão', 'battery': 'Pilhas e baterias', 'electronic': 'Eletrônicos'}
            st.dataframe([{'Material': names.get(label, label),
                           'Imagens de treino': result.get('training_counts', {}).get(label),
                           'Imagens de validação': metrics['support'],
                           'Acerto anterior (%)': round(metrics['reference_recall'] * 100, 1),
                           'Acerto candidato (%)': round(metrics['candidate_recall'] * 100, 1)}
                          for label, metrics in details.items()], hide_index=True)
            reason_labels = {'macro_f1_gain_below_minimum': 'Ganho de Macro-F1 insuficiente',
                             'insufficient_validation': 'Poucos exemplos de validação',
                             'recall_regression': 'Queda de acerto no material',
                             'more_confident_errors': 'Aumento de erros com confiança alta'}
            for reason in result.get('gate_reasons', []):
                label = names.get(reason.get('class_id'), reason.get('class_id', ''))
                st.write(reason_labels.get(reason['code'], reason['code']) + (f': {label}' if label else ''))
            st.caption('Validação histórica reutilizada. Estes resultados não medem a precisão em novas fotos de celular. Imagens de treino não equivalem a objetos distintos.')
        else:
            st.caption('Lote antigo: detalhamento por material não registrado.')


def render_citizen_protocols(st, config, profile):
    st.subheader("Minhas contribuições à secretaria")
    if profile.id.startswith("visitor_"):
        st.info("Entre em uma conta verificada para enviar e acompanhar contribuições. No modo visitante, nada é salvo no perfil.")
        return
    st.button("Atualizar protocolos", key="refresh_contributions")
    try:
        records = citizen_contributions(config, profile.id, actor=profile)
    except (OSError, ValueError, PermissionError) as exc:
        st.error(str(exc))
        return
    if persistent_enabled():
        st.caption("Consulta ao banco concluída. As contribuições enviadas ficam disponíveis para revisão da secretaria.")
    else:
        st.warning("Armazenamento temporário: baixe seus comprovantes e pacotes.")
    st.caption("Protocolos vinculados à sua conta. Use a mesma conta em outro dispositivo para acompanhá-los.")
    if not records:
        st.caption("Quando você reportar uma análise, o protocolo e a resposta da equipe aparecerão aqui.")
        return
    pending = sum(row["status"] == "pending" for row in records)
    st.caption(f"{len(records)} contribuição(ões) · {pending} aguardando revisão")
    for row in records:
        item = ITEMS.get(row["item_id"], (row["item_id"],))[0]
        status = STATUS_LABELS.get(row["status"], row["status"])
        with st.expander(f"{item} · {status}"):
            st.code(row["id"], language=None)
            st.write("**Resposta da secretaria:** " + (row["response"] or "Aguardando análise da equipe."))
            st.caption(STATUS_LABELS.get(row["training_status"], "Ainda não utilizado no treinamento"))
            st.download_button("Baixar protocolo", json.dumps(row, ensure_ascii=False, indent=2),
                               file_name=f"ecoscan-protocolo-{row['id']}.json", mime="application/json",
                               key=f"protocol_download_{row['id']}")


def render_contribution(st, config, result, profile):
    if profile.id.startswith("visitor_"):
        st.info("Para reportar esta análise à secretaria, entre em uma conta verificada. A foto do visitante não será guardada como contribuição.")
        return
    pixels = result.pipeline.loaded.array
    signature = hashlib.sha256(str(pixels.shape).encode() + pixels.tobytes()).hexdigest()[:16]
    receipt_key = f"contribution_receipt_{profile.id}_{signature}"
    with st.expander("O resultado está errado? Contribuir com uma correção", expanded=not result.accepted):
        st.caption("Sua correção entra na fila dos analistas da secretaria. Acompanhe a resposta em Perfil. Fotos aprovadas podem alimentar um modelo candidato, validado antes da publicação.")
        with st.form(f"contribution_form_{profile.id}_{signature}"):
            item = st.selectbox("O que aparece na foto?", list(REPORT_ITEMS), index=None,
                                placeholder="Escolha o item real", format_func=lambda key: ITEMS[key][0])
            condition = st.selectbox("Estado do objeto", list(ITEM_CONDITIONS),
                                     format_func=lambda key: ITEM_CONDITIONS[key])
            note = st.text_area("Observação opcional", max_chars=600,
                                placeholder="Ex.: lata amassada, foto com reflexo. Não informe dados pessoais.")
            consent = st.checkbox("Autorizo o grupo Recicla SP a guardar esta foto e usá-la na revisão e no treinamento. A foto é minha e não contém pessoas ou dados pessoais.")
            sent = st.form_submit_button("Enviar correção")
        if sent:
            try:
                record = submit_contribution(config, result, item_id=item, reporter_id=profile.id,
                                             consent=consent, note=note, condition=condition,
                                             actor=profile)
                st.session_state[receipt_key] = {
                    "record": record, "persistent": bool(record.get("storage_key")),
                    "received_at": datetime.now(timezone.utc).isoformat(), "package": None,
                }
            except (ValueError, OSError, PermissionError) as exc:
                st.error(str(exc) if isinstance(exc, ValueError) else
                         "Não foi possível confirmar o envio. Consulte Perfil → Atualizar protocolos antes de reenviar.")
        receipt = st.session_state.get(receipt_key)
        # Sessions opened before this release may still contain the old tuple.
        if receipt and not isinstance(receipt, dict):
            st.session_state.pop(receipt_key, None)
            receipt = None
        if receipt:
            identifier = receipt["record"]["id"]
            st.success(f"Contribuição recebida para revisão. Protocolo: {identifier[:8]}")
            if receipt["persistent"]:
                st.caption("Protocolo salvo no banco e foto em armazenamento privado. O pacote abaixo é uma cópia para você.")
            else:
                st.warning("Banco ainda não ativado. Baixe sua contribuição e envie ao responsável do grupo para preservá-la.")
            st.download_button("Baixar comprovante do envio", json.dumps({
                "protocol": identifier, "received_at": receipt["received_at"],
                "persistent": receipt["persistent"], "item_id": receipt["record"].get("item_id"),
                "status_at_submission": receipt["record"]["status"],
            }, ensure_ascii=False, indent=2), file_name=f"ecoscan-protocolo-{identifier}.json",
                mime="application/json", key=f"receipt_download_{signature}")
            if st.button("Preparar cópia com foto", key=f"prepare_receipt_{signature}"):
                try:
                    receipt["package"] = contribution_package(
                        config, [receipt["record"]], actor=profile)
                except (ValueError, OSError, PermissionError):
                    st.warning("Seu envio já foi confirmado. Não foi possível preparar a cópia agora; tente novamente sem reenviar a contribuição.")
            if receipt["package"] is not None:
                st.download_button("Baixar minha contribuição", receipt["package"],
                                   file_name=f"ecoscan-contribuicao-{identifier}.zip", mime="application/zip",
                                   key=f"download_{signature}")


def render_review(st, config, profile):
    if not profile.is_admin:
        return
    st.subheader("Central de análise da secretaria")
    try:
        records = list_contributions(config, actor=profile)
    except (OSError, ValueError, PermissionError) as exc:
        st.error(str(exc))
        return
    columns = st.columns(3)
    columns[0].metric("Aguardando análise", sum(row["status"] == "pending" for row in records))
    columns[1].metric("Aprovadas", sum(row["status"] == "approved" for row in records))
    columns[2].metric("Na fila de treino", sum(row.get("training_status") == "queued" for row in records))
    render_training(st, config, profile, records=records)
    st.caption("Confira foto e rótulo. A aprovação prepara o próximo treino; não altera o modelo em uso.")
    if not records:
        st.info("Nenhuma contribuição recebida nesta instância.")
        return
    selected = st.selectbox("Contribuição", records,
                            format_func=lambda row: f"{row['status']} · {ITEMS.get(row['item_id'], (row['item_id'],))[0]} · {row['id'][:8]}")
    try:
        st.image(str(contribution_image(config, selected, actor=profile)), width=300)
        st.write(f"Modelo sugeriu: {selected['feedback']['predicted_class'] or selected['feedback']['top_class'] or 'inconclusivo'}")
        st.write(selected["feedback"]["note"])
        st.write("Estado informado: " + ITEM_CONDITIONS.get(selected.get("condition", "unspecified"), "Não informado"))
        with st.expander("Contexto técnico da análise reportada"):
            context = selected.get("analysis_context", {})
            if context.get("availability") == "recorded":
                st.json(context)
                st.caption("Modelo: " + str(selected.get("model_sha256", "não registrado")))
                if context.get("model_processing_compatible") is False:
                    st.warning("A hipótese usou um modelo sem preparo compatível e não foi confirmada automaticamente.")
            else:
                st.caption("Contribuição anterior ao registro de contexto. Não é possível reconstruir a versão do preparo.")
        with st.form(f"review_contribution_{selected['id']}_{selected.get('revision', 0)}"):
            item_id = st.selectbox("Item confirmado pelo analista", list(ITEMS),
                                   index=list(ITEMS).index(selected["item_id"]),
                                   format_func=lambda key: ITEMS[key][0])
            decision = st.selectbox("Decisão", ["approved", "rejected"], index=None,
                                    format_func=lambda value: "Aprovar rótulo e foto" if value == "approved" else "Rejeitar")
            response = st.text_area("Resposta ao cidadão", max_chars=600,
                                    value=selected.get("response", ""),
                                    placeholder="Ex.: Confirmamos uma lata metálica. Obrigado pela contribuição.")
            if st.form_submit_button("Salvar revisão"):
                review_contribution(config, selected["id"], decision=decision, reviewer=profile,
                                    item_id=item_id, response=response,
                                    expected_revision=selected.get("revision", 0))
                st.session_state.pop("review_packages", None)
                st.rerun()
        if st.button("Preparar pacotes de contribuições"):
            st.session_state["review_packages"] = (
                contribution_package(config, records, actor=profile),
                contribution_package(config, records, approved_only=True, actor=profile),
            )
        packages = st.session_state.get("review_packages")
        if packages:
            st.download_button("Baixar fila para revisão offline", packages[0], "ecoscan-fila.zip", "application/zip")
            st.download_button("Baixar somente aprovadas", packages[1], "ecoscan-aprovadas.zip", "application/zip")
        st.caption("Fotos aprovadas ainda precisam de divisão entre treino, validação e teste. Mantenha cópias de segurança dos pacotes.")
    except (ValueError, OSError, PermissionError) as exc:
        st.error(str(exc))


def render_training(st, config, profile, *, records=None):
    if not profile.is_admin:
        return
    if persistent_enabled():
        st.info("As aprovações entram na fila de aprendizado. O executor externo, quando ativado, processa os lotes e só publica candidatos aprovados na validação. Aprovação da foto não significa publicação imediata.")
        records = list_contributions(config, actor=profile) if records is None else records
        render_evaluation(st, records)
        if records:
            st.dataframe([{"Protocolo": row["id"][:8],
                           "Aprendizado": STATUS_LABELS.get(row.get("training_status"), "Pendente"),
                           "Resultado": ("Melhoria aprovada" if row.get("training_result", {}).get("published")
                                          else "Critérios de melhoria não atendidos" if row.get("training_status") == "validation_failed"
                                          else "—"),
                           "Lote": row.get("candidate_id", "—")} for row in records], hide_index=True)
        return
    st.info(
        "O treinamento local antigo foi removido. Exporte as fotos aprovadas; "
        "a fila revisada usa somente o reconhecedor semântico atual e publica "
        "uma nova release após validação independente."
    )
