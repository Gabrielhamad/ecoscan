"""User interfaces for EcoScan."""

